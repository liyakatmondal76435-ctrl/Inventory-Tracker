package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.StockGainGreen
import com.example.ui.theme.StockLossRed
import com.example.ui.viewmodel.WeeklyDayData
import com.example.util.CurrencyFormatter
import kotlin.math.max

/**
 * Interactive Weekly Inventory Fluctuation Graph with touch tooltip scrubbing.
 */
@Composable
fun WeeklyQuantityFluctuationGraph(
    weeklyData: List<WeeklyDayData>,
    modifier: Modifier = Modifier
) {
    if (weeklyData.isEmpty()) return

    var selectedIndex by remember { mutableStateOf<Int?>(weeklyData.lastIndex) }
    val primaryColor = MaterialTheme.colorScheme.primary
    val surfaceVariant = MaterialTheme.colorScheme.surfaceVariant
    val outlineColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
    val textPaintColor = MaterialTheme.colorScheme.onSurface.hashCode()

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("weekly_quantity_graph_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header with interactive hint
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Weekly Stock Fluctuations",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Daily Inflow (+) vs Outflow (-)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.TouchApp,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Touch to inspect",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            // Legend
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(StockGainGreen, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Added (Inflow)",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(StockLossRed, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Deducted (Outflow)",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Interactive Tooltip Card for Selected Day
            AnimatedVisibility(
                visible = selectedIndex != null,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                selectedIndex?.let { index ->
                    val dayData = weeklyData.getOrNull(index)
                    if (dayData != null) {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${dayData.dayLabel}, ${dayData.dateFormatted}",
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.onSecondaryContainer
                                    )
                                    Text(
                                        text = "Net: ${if (dayData.netQuantity >= 0) "+" else ""}${CurrencyFormatter.formatQuantity(dayData.netQuantity)} units",
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = if (dayData.netQuantity >= 0) StockGainGreen else StockLossRed
                                        )
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Added: +${CurrencyFormatter.formatQuantity(dayData.unitsAdded)} (${CurrencyFormatter.formatInr(dayData.valueAddedInr)})",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = StockGainGreen
                                    )
                                    Text(
                                        text = "Deducted: -${CurrencyFormatter.formatQuantity(dayData.unitsDeducted)} (${CurrencyFormatter.formatInr(dayData.valueDeductedInr)})",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = StockLossRed
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Canvas Bar Chart
            val maxUnits = max(
                10.0,
                weeklyData.maxOfOrNull { max(it.unitsAdded, it.unitsDeducted) } ?: 10.0
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .pointerInput(weeklyData) {
                            detectTapGestures { offset ->
                                val slotWidth = size.width / weeklyData.size
                                val index = (offset.x / slotWidth).toInt().coerceIn(0, weeklyData.lastIndex)
                                selectedIndex = index
                            }
                        }
                        .pointerInput(weeklyData) {
                            detectDragGestures { change, _ ->
                                val slotWidth = size.width / weeklyData.size
                                val index = (change.position.x / slotWidth).toInt().coerceIn(0, weeklyData.lastIndex)
                                selectedIndex = index
                            }
                        }
                ) {
                    val width = size.width
                    val height = size.height
                    val bottomPadding = 32.dp.toPx()
                    val chartHeight = height - bottomPadding
                    val count = weeklyData.size
                    val slotWidth = width / count
                    val barWidth = (slotWidth * 0.28f).coerceAtMost(24.dp.toPx())

                    // Baseline grid
                    drawLine(
                        color = outlineColor,
                        start = Offset(0f, chartHeight),
                        end = Offset(width, chartHeight),
                        strokeWidth = 1.dp.toPx()
                    )

                    weeklyData.forEachIndexed { index, data ->
                        val centerX = slotWidth * index + slotWidth / 2f
                        val isSelected = selectedIndex == index

                        // Highlight background for selected column
                        if (isSelected) {
                            drawRoundRect(
                                color = primaryColor.copy(alpha = 0.08f),
                                topLeft = Offset(slotWidth * index, 0f),
                                size = Size(slotWidth, chartHeight + bottomPadding),
                                cornerRadius = CornerRadius(8.dp.toPx())
                            )

                            // Scrubber vertical dashed line
                            drawLine(
                                color = primaryColor.copy(alpha = 0.5f),
                                start = Offset(centerX, 0f),
                                end = Offset(centerX, chartHeight),
                                strokeWidth = 1.5.dp.toPx(),
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f))
                            )
                        }

                        // Added bar (green)
                        val addedRatio = (data.unitsAdded / maxUnits).toFloat().coerceIn(0f, 1f)
                        val addedBarHeight = (chartHeight * 0.9f) * addedRatio
                        if (addedBarHeight > 0) {
                            drawRoundRect(
                                color = StockGainGreen,
                                topLeft = Offset(centerX - barWidth - 2.dp.toPx(), chartHeight - addedBarHeight),
                                size = Size(barWidth, addedBarHeight),
                                cornerRadius = CornerRadius(4.dp.toPx())
                            )
                        }

                        // Deducted bar (red)
                        val deductedRatio = (data.unitsDeducted / maxUnits).toFloat().coerceIn(0f, 1f)
                        val deductedBarHeight = (chartHeight * 0.9f) * deductedRatio
                        if (deductedBarHeight > 0) {
                            drawRoundRect(
                                color = StockLossRed,
                                topLeft = Offset(centerX + 2.dp.toPx(), chartHeight - deductedBarHeight),
                                size = Size(barWidth, deductedBarHeight),
                                cornerRadius = CornerRadius(4.dp.toPx())
                            )
                        }

                        // Day label on bottom
                        drawContext.canvas.nativeCanvas.apply {
                            val paint = android.graphics.Paint().apply {
                                color = if (isSelected) primaryColor.hashCode() else textPaintColor
                                textSize = 11.sp.toPx()
                                textAlign = android.graphics.Paint.Align.CENTER
                                isFakeBoldText = isSelected
                            }
                            drawText(
                                data.dayLabel,
                                centerX,
                                height - 8.dp.toPx(),
                                paint
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Interactive Weekly Stock Valuation & Price Trend Graph (in INR) with touch tooltip scrubbing.
 */
@Composable
fun WeeklyPriceValuationGraph(
    weeklyData: List<WeeklyDayData>,
    modifier: Modifier = Modifier
) {
    if (weeklyData.isEmpty()) return

    var selectedIndex by remember { mutableStateOf<Int?>(weeklyData.lastIndex) }
    val primaryColor = MaterialTheme.colorScheme.primary
    val tertiaryColor = MaterialTheme.colorScheme.tertiary
    val surfaceColor = MaterialTheme.colorScheme.surface
    val outlineColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
    val textPaintColor = MaterialTheme.colorScheme.onSurface.hashCode()

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("weekly_price_graph_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Total Valuation Trend (INR)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Weekly inventory value trajectory in ₹",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.TouchApp,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = tertiaryColor
                    )
                    Text(
                        text = "Scrub timeline",
                        style = MaterialTheme.typography.labelSmall,
                        color = tertiaryColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Interactive Tooltip Card for Selected Valuation Point
            AnimatedVisibility(
                visible = selectedIndex != null,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                selectedIndex?.let { index ->
                    val dayData = weeklyData.getOrNull(index)
                    if (dayData != null) {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.6f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "${dayData.dayLabel}, ${dayData.dateFormatted}",
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.onTertiaryContainer
                                    )
                                    Text(
                                        text = "Inflow: +${CurrencyFormatter.formatInr(dayData.valueAddedInr)} | Outflow: -${CurrencyFormatter.formatInr(dayData.valueDeductedInr)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.8f)
                                    )
                                }
                                Text(
                                    text = CurrencyFormatter.formatInr(dayData.estimatedValuationInr),
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                        color = MaterialTheme.colorScheme.onTertiaryContainer
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // Curve Line Graph with Gradient Fill
            val minValuation = (weeklyData.minOfOrNull { it.estimatedValuationInr } ?: 0.0) * 0.9
            val maxValuation = (weeklyData.maxOfOrNull { it.estimatedValuationInr } ?: 1000.0) * 1.1
            val range = (maxValuation - minValuation).coerceAtLeast(100.0)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .pointerInput(weeklyData) {
                            detectTapGestures { offset ->
                                val slotWidth = size.width / (weeklyData.size - 1).coerceAtLeast(1)
                                val index = ((offset.x + slotWidth / 2) / slotWidth).toInt().coerceIn(0, weeklyData.lastIndex)
                                selectedIndex = index
                            }
                        }
                        .pointerInput(weeklyData) {
                            detectDragGestures { change, _ ->
                                val slotWidth = size.width / (weeklyData.size - 1).coerceAtLeast(1)
                                val index = ((change.position.x + slotWidth / 2) / slotWidth).toInt().coerceIn(0, weeklyData.lastIndex)
                                selectedIndex = index
                            }
                        }
                ) {
                    val width = size.width
                    val height = size.height
                    val bottomPadding = 32.dp.toPx()
                    val topPadding = 16.dp.toPx()
                    val chartHeight = height - bottomPadding - topPadding
                    val count = weeklyData.size
                    if (count < 2) return@Canvas

                    val stepX = width / (count - 1)

                    val points = weeklyData.mapIndexed { index, item ->
                        val x = stepX * index
                        val ratio = ((item.estimatedValuationInr - minValuation) / range).toFloat().coerceIn(0f, 1f)
                        val y = (topPadding + chartHeight) - (chartHeight * ratio)
                        Offset(x, y)
                    }

                    // Horizontal guidelines
                    for (i in 0..2) {
                        val guideY = topPadding + (chartHeight / 2) * i
                        drawLine(
                            color = outlineColor,
                            start = Offset(0f, guideY),
                            end = Offset(width, guideY),
                            strokeWidth = 0.8.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
                        )
                    }

                    // Build smooth cubic bezier curve
                    val linePath = Path()
                    val fillPath = Path()

                    points.firstOrNull()?.let { first ->
                        linePath.moveTo(first.x, first.y)
                        fillPath.moveTo(first.x, topPadding + chartHeight)
                        fillPath.lineTo(first.x, first.y)

                        for (i in 1 until points.size) {
                            val prev = points[i - 1]
                            val curr = points[i]
                            val midX = (prev.x + curr.x) / 2f
                            linePath.cubicTo(midX, prev.y, midX, curr.y, curr.x, curr.y)
                            fillPath.cubicTo(midX, prev.y, midX, curr.y, curr.x, curr.y)
                        }

                        val last = points.last()
                        fillPath.lineTo(last.x, topPadding + chartHeight)
                        fillPath.close()
                    }

                    // Draw gradient area fill
                    drawPath(
                        path = fillPath,
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                tertiaryColor.copy(alpha = 0.35f),
                                tertiaryColor.copy(alpha = 0.02f)
                            ),
                            startY = topPadding,
                            endY = topPadding + chartHeight
                        )
                    )

                    // Draw smooth curve stroke
                    drawPath(
                        path = linePath,
                        color = tertiaryColor,
                        style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                    )

                    // Draw indicator points and touch scrubber
                    points.forEachIndexed { index, point ->
                        val isSelected = selectedIndex == index

                        if (isSelected) {
                            // Scrubber vertical dashed line
                            drawLine(
                                color = tertiaryColor.copy(alpha = 0.6f),
                                start = Offset(point.x, topPadding),
                                end = Offset(point.x, topPadding + chartHeight),
                                strokeWidth = 1.5.dp.toPx(),
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f))
                            )

                            // Outer pulse halo
                            drawCircle(
                                color = tertiaryColor.copy(alpha = 0.25f),
                                radius = 10.dp.toPx(),
                                center = point
                            )
                            // Inner solid dot
                            drawCircle(
                                color = tertiaryColor,
                                radius = 5.dp.toPx(),
                                center = point
                            )
                        } else {
                            // Subtle point
                            drawCircle(
                                color = surfaceColor,
                                radius = 4.dp.toPx(),
                                center = point
                            )
                            drawCircle(
                                color = tertiaryColor,
                                radius = 4.dp.toPx(),
                                center = point,
                                style = Stroke(width = 2.dp.toPx())
                            )
                        }

                        // Day label below
                        drawContext.canvas.nativeCanvas.apply {
                            val paint = android.graphics.Paint().apply {
                                color = if (isSelected) tertiaryColor.hashCode() else textPaintColor
                                textSize = 11.sp.toPx()
                                textAlign = android.graphics.Paint.Align.CENTER
                                isFakeBoldText = isSelected
                            }
                            drawText(
                                weeklyData[index].dayLabel,
                                point.x,
                                height - 8.dp.toPx(),
                                paint
                            )
                        }
                    }
                }
            }
        }
    }
}
