package com.example.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.outlined.Analytics
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.InventoryListScreen
import com.example.ui.screens.TransactionHistoryScreen
import com.example.ui.viewmodel.InventoryViewModel

enum class NavTab {
    INVENTORY,
    ANALYTICS,
    HISTORY
}

@Composable
fun MainApp(
    isDarkMode: Boolean,
    onToggleDarkMode: () -> Unit,
    viewModel: InventoryViewModel = viewModel()
) {
    var currentTab by remember { mutableStateOf(NavTab.INVENTORY) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(modifier = Modifier.testTag("bottom_nav_bar")) {
                NavigationBarItem(
                    selected = currentTab == NavTab.INVENTORY,
                    onClick = { currentTab = NavTab.INVENTORY },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == NavTab.INVENTORY) Icons.Filled.Inventory2 else Icons.Outlined.Inventory2,
                            contentDescription = "Stock Items"
                        )
                    },
                    label = { Text("Inventory") },
                    modifier = Modifier.testTag("nav_tab_inventory")
                )

                NavigationBarItem(
                    selected = currentTab == NavTab.ANALYTICS,
                    onClick = { currentTab = NavTab.ANALYTICS },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == NavTab.ANALYTICS) Icons.Filled.Analytics else Icons.Outlined.Analytics,
                            contentDescription = "Analytics & Graphs"
                        )
                    },
                    label = { Text("Analytics") },
                    modifier = Modifier.testTag("nav_tab_analytics")
                )

                NavigationBarItem(
                    selected = currentTab == NavTab.HISTORY,
                    onClick = { currentTab = NavTab.HISTORY },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == NavTab.HISTORY) Icons.Filled.History else Icons.Outlined.History,
                            contentDescription = "Transaction History"
                        )
                    },
                    label = { Text("History") },
                    modifier = Modifier.testTag("nav_tab_history")
                )
            }
        }
    ) { innerPadding ->
        when (currentTab) {
            NavTab.INVENTORY -> {
                InventoryListScreen(
                    viewModel = viewModel,
                    isDarkMode = isDarkMode,
                    onToggleDarkMode = onToggleDarkMode,
                    modifier = Modifier.padding(innerPadding)
                )
            }
            NavTab.ANALYTICS -> {
                AnalyticsScreen(
                    viewModel = viewModel,
                    modifier = Modifier.padding(innerPadding)
                )
            }
            NavTab.HISTORY -> {
                TransactionHistoryScreen(
                    viewModel = viewModel,
                    modifier = Modifier.padding(innerPadding)
                )
            }
        }
    }
}
