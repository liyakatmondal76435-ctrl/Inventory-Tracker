package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Color Scheme
val PrimaryLight = Color(0xFF006A60)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFF73F8E5)
val OnPrimaryContainerLight = Color(0xFF00201C)

val SecondaryLight = Color(0xFF4A635F)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFCCE8E3)
val OnSecondaryContainerLight = Color(0xFF05201C)

val TertiaryLight = Color(0xFF8B5000)
val OnTertiaryLight = Color(0xFFFFFFFF)
val TertiaryContainerLight = Color(0xFFFFDCBE)
val OnTertiaryContainerLight = Color(0xFF2C1600)

val BackgroundLight = Color(0xFFF4F7F6)
val OnBackgroundLight = Color(0xFF191C1B)
val SurfaceLight = Color(0xFFFAFDFB)
val OnSurfaceLight = Color(0xFF191C1B)
val SurfaceVariantLight = Color(0xFFDAE5E1)
val OnSurfaceVariantLight = Color(0xFF3F4946)
val OutlineLight = Color(0xFF6F7976)

// Dark Color Scheme
val PrimaryDark = Color(0xFF53DBC9)
val OnPrimaryDark = Color(0xFF003731)
val PrimaryContainerLightDark = Color(0xFF005048)
val OnPrimaryContainerLightDark = Color(0xFF73F8E5)

val SecondaryDark = Color(0xFFB1CCC6)
val OnSecondaryDark = Color(0xFF1C3531)
val SecondaryContainerDark = Color(0xFF324B47)
val OnSecondaryContainerDark = Color(0xFFCCE8E3)

val TertiaryDark = Color(0xFFFFB870)
val OnTertiaryDark = Color(0xFF4A2800)
val TertiaryContainerDark = Color(0xFF693C00)
val OnTertiaryContainerDark = Color(0xFFFFDCBE)

val BackgroundDark = Color(0xFF111414)
val OnBackgroundDark = Color(0xFFE0E3E1)
val SurfaceDark = Color(0xFF161A19)
val OnSurfaceDark = Color(0xFFE0E3E1)
val SurfaceVariantDark = Color(0xFF3F4946)
val OnSurfaceVariantDark = Color(0xFFBEC9C5)
val OutlineDark = Color(0xFF899390)

// Expressive semantic accents
val StockGainGreen = Color(0xFF16A34A)
val StockGainGreenDark = Color(0xFF4ADE80)
val StockLossRed = Color(0xFFDC2626)
val StockLossRedDark = Color(0xFFF87171)
val WarningAmber = Color(0xFFD97706)
val WarningAmberDark = Color(0xFFFBBF24)
