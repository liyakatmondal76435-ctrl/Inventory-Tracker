package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.InventoryDatabase
import com.example.data.local.InventoryItem
import com.example.data.local.TransactionLog
import com.example.data.repository.InventoryRepository
import com.example.util.CurrencyFormatter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.Calendar
import kotlin.math.abs

data class InventoryStats(
    val totalValueInr: Double = 0.0,
    val totalItemCount: Int = 0,
    val totalUnitsCount: Double = 0.0,
    val lowStockCount: Int = 0
)

data class WeeklyDayData(
    val dayLabel: String,
    val dateFormatted: String,
    val timestamp: Long,
    val unitsAdded: Double,
    val unitsDeducted: Double,
    val netQuantity: Double,
    val valueAddedInr: Double,
    val valueDeductedInr: Double,
    val estimatedValuationInr: Double
)

data class CategoryValuation(
    val category: String,
    val totalValue: Double,
    val itemCount: Int,
    val percentage: Float
)

class InventoryViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: InventoryRepository

    init {
        val database = InventoryDatabase.getDatabase(application, viewModelScope)
        repository = InventoryRepository(database.inventoryDao(), database.transactionLogDao())
    }

    // Search and filter state
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow<String?>(null)
    val selectedCategory: StateFlow<String?> = _selectedCategory.asStateFlow()

    private val _onlyLowStock = MutableStateFlow(false)
    val onlyLowStock: StateFlow<Boolean> = _onlyLowStock.asStateFlow()

    // History filter states
    private val _historyActionFilter = MutableStateFlow("ALL") // "ALL", "ADDED", "DEDUCTED"
    val historyActionFilter: StateFlow<String> = _historyActionFilter.asStateFlow()

    private val _historyTimeRange = MutableStateFlow("ALL") // "ALL", "TODAY", "WEEK", "MONTH"
    val historyTimeRange: StateFlow<String> = _historyTimeRange.asStateFlow()

    private val _historySearchQuery = MutableStateFlow("")
    val historySearchQuery: StateFlow<String> = _historySearchQuery.asStateFlow()

    // Notification / Toast channel
    private val _eventMessage = MutableSharedFlow<String>()
    val eventMessage: SharedFlow<String> = _eventMessage.asSharedFlow()

    // All Items from database
    val rawItems: StateFlow<List<InventoryItem>> = repository.allItems
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // All Logs from database
    val rawLogs: StateFlow<List<TransactionLog>> = repository.allLogs
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Categories list dynamically calculated
    val categories: StateFlow<List<String>> = rawItems.combine(_selectedCategory) { items, _ ->
        items.map { it.category.trim() }.distinct().sorted()
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Filtered Items for Main Screen
    val filteredItems: StateFlow<List<InventoryItem>> = combine(
        rawItems,
        _searchQuery,
        _selectedCategory,
        _onlyLowStock
    ) { items, query, category, lowStockOnly ->
        items.filter { item ->
            val matchesQuery = query.isBlank() ||
                item.name.contains(query, ignoreCase = true) ||
                item.category.contains(query, ignoreCase = true) ||
                item.sku.contains(query, ignoreCase = true)

            val matchesCategory = category == null || item.category.equals(category, ignoreCase = true)
            val matchesLowStock = !lowStockOnly || item.isLowStock

            matchesQuery && matchesCategory && matchesLowStock
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Overall Summary Metrics
    val inventoryStats: StateFlow<InventoryStats> = rawItems.combine(rawLogs) { items, _ ->
        val totalVal = items.sumOf { it.totalValue }
        val totalUnits = items.sumOf { it.quantity }
        val lowStock = items.count { it.isLowStock }
        InventoryStats(
            totalValueInr = totalVal,
            totalItemCount = items.size,
            totalUnitsCount = totalUnits,
            lowStockCount = lowStock
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = InventoryStats()
    )

    // Filtered Transaction Logs
    val filteredLogs: StateFlow<List<TransactionLog>> = combine(
        rawLogs,
        _historyActionFilter,
        _historyTimeRange,
        _historySearchQuery
    ) { logs, actionFilter, timeRange, query ->
        val now = System.currentTimeMillis()
        val calendar = Calendar.getInstance()

        val periodStart = when (timeRange) {
            "TODAY" -> {
                calendar.timeInMillis = now
                calendar.set(Calendar.HOUR_OF_DAY, 0)
                calendar.set(Calendar.MINUTE, 0)
                calendar.set(Calendar.SECOND, 0)
                calendar.set(Calendar.MILLISECOND, 0)
                calendar.timeInMillis
            }
            "WEEK" -> now - (7L * 24 * 60 * 60 * 1000)
            "MONTH" -> now - (30L * 24 * 60 * 60 * 1000)
            else -> 0L
        }

        logs.filter { log ->
            val matchesAction = when (actionFilter) {
                "ADDED" -> log.actionType == "ADDED"
                "DEDUCTED" -> log.actionType == "DEDUCTED"
                else -> true
            }

            val matchesTime = log.timestamp >= periodStart

            val matchesQuery = query.isBlank() ||
                log.itemName.contains(query, ignoreCase = true) ||
                log.notes.contains(query, ignoreCase = true)

            matchesAction && matchesTime && matchesQuery
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Weekly Fluctuations & Valuation Progression Data (7 Days)
    val weeklyFluctuationData: StateFlow<List<WeeklyDayData>> = combine(rawLogs, rawItems) { logs, items ->
        computeWeeklyFluctuations(logs, items)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Category valuation breakdown
    val categoryValuations: StateFlow<List<CategoryValuation>> = rawItems.combine(_selectedCategory) { items, _ ->
        val totalVal = items.sumOf { it.totalValue }.coerceAtLeast(1.0)
        items.groupBy { it.category }
            .map { (cat, catItems) ->
                val catVal = catItems.sumOf { it.totalValue }
                CategoryValuation(
                    category = cat,
                    totalValue = catVal,
                    itemCount = catItems.size,
                    percentage = (catVal / totalVal * 100).toFloat()
                )
            }
            .sortedByDescending { it.totalValue }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // UI Search and Filter setters
    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedCategory(category: String?) {
        _selectedCategory.value = category
    }

    fun toggleLowStockOnly() {
        _onlyLowStock.value = !_onlyLowStock.value
    }

    fun setHistoryActionFilter(action: String) {
        _historyActionFilter.value = action
    }

    fun setHistoryTimeRange(range: String) {
        _historyTimeRange.value = range
    }

    fun setHistorySearchQuery(query: String) {
        _historySearchQuery.value = query
    }

    // Quick Action: +1
    fun quickAddOne(item: InventoryItem) {
        viewModelScope.launch {
            repository.adjustStock(
                item = item,
                delta = 1.0,
                actionReason = "Quick +1",
                actionType = "ADDED"
            )
            val addedVal = CurrencyFormatter.formatInr(item.unitPrice)
            _eventMessage.emit("+1 ${item.unit} added to ${item.name} (+$addedVal)")
        }
    }

    // Quick Action: -1
    fun quickSubtractOne(item: InventoryItem) {
        if (item.quantity <= 0) {
            viewModelScope.launch {
                _eventMessage.emit("${item.name} is already out of stock!")
            }
            return
        }
        viewModelScope.launch {
            repository.adjustStock(
                item = item,
                delta = -1.0,
                actionReason = "Quick -1",
                actionType = "DEDUCTED"
            )
            val deductedVal = CurrencyFormatter.formatInr(item.unitPrice)
            _eventMessage.emit("-1 ${item.unit} deducted from ${item.name} (-$deductedVal)")
        }
    }

    // Manual stock adjustment with reason
    fun adjustStockQuantity(item: InventoryItem, delta: Double, reason: String) {
        viewModelScope.launch {
            val actionType = if (delta >= 0) "ADDED" else "DEDUCTED"
            repository.adjustStock(
                item = item,
                delta = delta,
                actionReason = reason.ifBlank { if (delta >= 0) "Manual Stock Addition" else "Manual Stock Deduction" },
                actionType = actionType
            )
            val financialImpact = abs(delta) * item.unitPrice
            val formattedImpact = CurrencyFormatter.formatInr(financialImpact)
            val sign = if (delta >= 0) "+" else "-"
            _eventMessage.emit("Updated ${item.name}: $sign${CurrencyFormatter.formatQuantity(abs(delta))} ${item.unit} ($sign$formattedImpact)")
        }
    }

    // Exact number edit
    fun setExactStock(item: InventoryItem, newQuantity: Double, reason: String) {
        viewModelScope.launch {
            val delta = newQuantity - item.quantity
            val actionType = if (delta >= 0) "ADDED" else "DEDUCTED"
            repository.setStockDirect(
                item = item,
                newQuantity = newQuantity,
                reason = reason.ifBlank { "Manual stock count adjustment" }
            )
            val financialImpact = abs(delta) * item.unitPrice
            val formattedImpact = CurrencyFormatter.formatInr(financialImpact)
            val sign = if (delta >= 0) "+" else "-"
            _eventMessage.emit("Set ${item.name} to ${CurrencyFormatter.formatQuantity(newQuantity)} ${item.unit} ($sign$formattedImpact)")
        }
    }

    // Save or update item
    fun saveItem(
        id: Long = 0,
        name: String,
        category: String,
        unit: String,
        quantity: Double,
        unitPrice: Double,
        lowStockThreshold: Double,
        sku: String,
        isNew: Boolean
    ) {
        viewModelScope.launch {
            if (isNew) {
                val item = InventoryItem(
                    id = 0,
                    name = name.trim(),
                    category = category.trim().ifBlank { "General" },
                    unit = unit.trim().ifBlank { "pcs" },
                    quantity = quantity,
                    unitPrice = unitPrice,
                    lowStockThreshold = lowStockThreshold,
                    sku = sku.trim(),
                    lastUpdated = System.currentTimeMillis()
                )
                repository.addItem(item, "New item registered")
                _eventMessage.emit("Item added: ${item.name} (${CurrencyFormatter.formatInr(item.totalValue)})")
            } else {
                val existing = rawItems.value.find { it.id == id }
                if (existing != null) {
                    val quantityDelta = quantity - existing.quantity
                    val updated = existing.copy(
                        name = name.trim(),
                        category = category.trim().ifBlank { "General" },
                        unit = unit.trim().ifBlank { "pcs" },
                        quantity = quantity,
                        unitPrice = unitPrice,
                        lowStockThreshold = lowStockThreshold,
                        sku = sku.trim(),
                        lastUpdated = System.currentTimeMillis()
                    )
                    repository.updateItemDetails(updated)
                    if (quantityDelta != 0.0) {
                        repository.adjustStock(
                            item = existing,
                            delta = quantityDelta,
                            actionReason = "Item edited in dialog",
                            actionType = if (quantityDelta > 0) "ADDED" else "DEDUCTED"
                        )
                    }
                    _eventMessage.emit("Updated ${updated.name}")
                }
            }
        }
    }

    // Delete item
    fun deleteItem(item: InventoryItem) {
        viewModelScope.launch {
            repository.deleteItem(item)
            _eventMessage.emit("Removed ${item.name} from inventory")
        }
    }

    // Clear history logs
    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
            _eventMessage.emit("Transaction history cleared")
        }
    }

    // CSV Export to URI
    fun exportItemsToUri(context: Context, uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val csv = repository.exportItemsCsv()
                context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                    OutputStreamWriter(outputStream).use { writer ->
                        writer.write(csv)
                    }
                }
                _eventMessage.emit("Inventory items exported successfully to CSV!")
            } catch (e: Exception) {
                _eventMessage.emit("Failed to export items: ${e.localizedMessage}")
            }
        }
    }

    fun exportLogsToUri(context: Context, uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val csv = repository.exportLogsCsv()
                context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                    OutputStreamWriter(outputStream).use { writer ->
                        writer.write(csv)
                    }
                }
                _eventMessage.emit("Transaction history exported successfully to CSV!")
            } catch (e: Exception) {
                _eventMessage.emit("Failed to export history: ${e.localizedMessage}")
            }
        }
    }

    // CSV Import from URI
    fun importItemsFromUri(context: Context, uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val stringBuilder = StringBuilder()
                context.contentResolver.openInputStream(uri)?.use { inputStream ->
                    BufferedReader(InputStreamReader(inputStream)).use { reader ->
                        var line = reader.readLine()
                        while (line != null) {
                            stringBuilder.append(line).append("\n")
                            line = reader.readLine()
                        }
                    }
                }
                val count = repository.importItemsCsv(stringBuilder.toString())
                _eventMessage.emit("Successfully imported $count items from CSV backup!")
            } catch (e: Exception) {
                _eventMessage.emit("Failed to import CSV: ${e.localizedMessage}")
            }
        }
    }

    suspend fun getExportItemsString(): String = withContext(Dispatchers.IO) {
        repository.exportItemsCsv()
    }

    suspend fun getExportLogsString(): String = withContext(Dispatchers.IO) {
        repository.exportLogsCsv()
    }

    private fun computeWeeklyFluctuations(
        logs: List<TransactionLog>,
        items: List<InventoryItem>
    ): List<WeeklyDayData> {
        val currentTotalValuation = items.sumOf { it.totalValue }
        val now = System.currentTimeMillis()
        val oneDayMillis = 24 * 60 * 60 * 1000L

        // Generate 7 days ending today
        val dayDataList = mutableListOf<WeeklyDayData>()

        for (i in 6 downTo 0) {
            val dayStart = now - (i * oneDayMillis)
            val cal = Calendar.getInstance().apply { timeInMillis = dayStart }
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            val startMillis = cal.timeInMillis
            val endMillis = startMillis + oneDayMillis

            val dayLogs = logs.filter { it.timestamp in startMillis until endMillis }
            var addedUnits = 0.0
            var deductedUnits = 0.0
            var addedInr = 0.0
            var deductedInr = 0.0

            for (log in dayLogs) {
                if (log.actionType == "ADDED") {
                    addedUnits += abs(log.quantityChange)
                    addedInr += log.totalAmount
                } else if (log.actionType == "DEDUCTED") {
                    deductedUnits += abs(log.quantityChange)
                    deductedInr += log.totalAmount
                }
            }

            // Estimate valuation trajectory backwards from current
            // If day is today (i == 0), valuation is currentTotalValuation
            // For past days, adjust according to transactions since then
            val logsAfterThisDay = logs.filter { it.timestamp >= endMillis }
            val netValuationChangeSince = logsAfterThisDay.sumOf { log ->
                if (log.actionType == "ADDED") log.totalAmount
                else if (log.actionType == "DEDUCTED") -log.totalAmount
                else 0.0
            }
            val estimatedDayValuation = (currentTotalValuation - netValuationChangeSince).coerceAtLeast(0.0)

            val dayLabel = CurrencyFormatter.formatDayOfWeek(startMillis)
            val dateFormatted = CurrencyFormatter.formatDate(startMillis)

            dayDataList.add(
                WeeklyDayData(
                    dayLabel = dayLabel,
                    dateFormatted = dateFormatted,
                    timestamp = startMillis,
                    unitsAdded = addedUnits,
                    unitsDeducted = deductedUnits,
                    netQuantity = addedUnits - deductedUnits,
                    valueAddedInr = addedInr,
                    valueDeductedInr = deductedInr,
                    estimatedValuationInr = estimatedDayValuation
                )
            )
        }

        return dayDataList
    }
}
