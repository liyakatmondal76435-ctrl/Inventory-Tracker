package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.InventoryItem
import com.example.util.CurrencyFormatter

@Composable
fun ItemEditDialog(
    item: InventoryItem?,
    existingCategories: List<String>,
    onDismiss: () -> Unit,
    onSave: (
        id: Long,
        name: String,
        category: String,
        unit: String,
        quantity: Double,
        unitPrice: Double,
        lowStockThreshold: Double,
        sku: String,
        isNew: Boolean
    ) -> Unit
) {
    val isNew = item == null

    var name by remember { mutableStateOf(item?.name ?: "") }
    var category by remember { mutableStateOf(item?.category ?: "Groceries") }
    var unit by remember { mutableStateOf(item?.unit ?: "pcs") }
    var quantityText by remember {
        mutableStateOf(if (item != null) CurrencyFormatter.formatQuantity(item.quantity) else "10")
    }
    var unitPriceText by remember {
        mutableStateOf(if (item != null) item.unitPrice.toString() else "100.0")
    }
    var lowStockThresholdText by remember {
        mutableStateOf(if (item != null) CurrencyFormatter.formatQuantity(item.lowStockThreshold) else "5")
    }
    var sku by remember { mutableStateOf(item?.sku ?: "") }

    var nameError by remember { mutableStateOf(false) }

    val calculatedQuantity = quantityText.toDoubleOrNull() ?: 0.0
    val calculatedPrice = unitPriceText.toDoubleOrNull() ?: 0.0
    val calculatedTotalValue = calculatedQuantity * calculatedPrice

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isNew) "Add New Item" else "Edit Item Details",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Item Name
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        nameError = it.isBlank()
                    },
                    label = { Text("Item Name *") },
                    placeholder = { Text("e.g. Colgate MaxFresh") },
                    isError = nameError,
                    supportingText = if (nameError) {
                        { Text("Item name is required") }
                    } else null,
                    leadingIcon = {
                        Icon(Icons.Default.Inventory2, contentDescription = null)
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("item_name_input"),
                    shape = RoundedCornerShape(12.dp)
                )

                // Category & Unit Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = category,
                        onValueChange = { category = it },
                        label = { Text("Category") },
                        placeholder = { Text("Groceries") },
                        leadingIcon = {
                            Icon(Icons.Default.Category, contentDescription = null)
                        },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1.2f)
                            .testTag("item_category_input"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = unit,
                        onValueChange = { unit = it },
                        label = { Text("Unit") },
                        placeholder = { Text("pcs, kg") },
                        singleLine = true,
                        modifier = Modifier
                            .weight(0.8f)
                            .testTag("item_unit_input"),
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                // Quantity & Unit Price Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = quantityText,
                        onValueChange = { quantityText = it },
                        label = { Text("Quantity") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("item_quantity_input"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = unitPriceText,
                        onValueChange = { unitPriceText = it },
                        label = { Text("Unit Price (₹)") },
                        leadingIcon = {
                            Icon(Icons.Default.CurrencyRupee, contentDescription = null)
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("item_price_input"),
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                // Low Stock Threshold & SKU
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = lowStockThresholdText,
                        onValueChange = { lowStockThresholdText = it },
                        label = { Text("Low Stock Alert ≤") },
                        leadingIcon = {
                            Icon(Icons.Default.Warning, contentDescription = null)
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("item_threshold_input"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = sku,
                        onValueChange = { sku = it },
                        label = { Text("SKU / Code") },
                        placeholder = { Text("Optional") },
                        leadingIcon = {
                            Icon(Icons.Default.QrCode, contentDescription = null)
                        },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("item_sku_input"),
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                // Dynamic Total Valuation Preview Banner
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "CALCULATED STOCK VALUE",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                            )
                            Text(
                                text = "${CurrencyFormatter.formatQuantity(calculatedQuantity)} $unit × ${CurrencyFormatter.formatInr(calculatedPrice)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                        Text(
                            text = CurrencyFormatter.formatInr(calculatedTotalValue),
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank()) {
                        nameError = true
                        return@Button
                    }
                    val qty = quantityText.toDoubleOrNull() ?: 0.0
                    val price = unitPriceText.toDoubleOrNull() ?: 0.0
                    val threshold = lowStockThresholdText.toDoubleOrNull() ?: 5.0
                    onSave(
                        item?.id ?: 0L,
                        name,
                        category,
                        unit,
                        qty,
                        price,
                        threshold,
                        sku,
                        isNew
                    )
                },
                modifier = Modifier.testTag("save_item_button")
            ) {
                Text(if (isNew) "Add Item" else "Save Changes")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        },
        shape = RoundedCornerShape(24.dp)
    )
}
