package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.InventoryItem
import com.example.ui.theme.StockGainGreen
import com.example.ui.theme.StockLossRed
import com.example.util.CurrencyFormatter
import kotlin.math.abs

@Composable
fun QuickAdjustStockDialog(
    item: InventoryItem,
    onDismiss: () -> Unit,
    onConfirmAdjustment: (newQuantity: Double, delta: Double, reason: String) -> Unit
) {
    var targetQuantity by remember { mutableDoubleStateOf(item.quantity) }
    var quantityInputText by remember {
        mutableStateOf(CurrencyFormatter.formatQuantity(item.quantity))
    }
    var selectedReason by remember { mutableStateOf("Supplier Restock") }
    var customReason by remember { mutableStateOf("") }

    val presetReasons = listOf("Supplier Restock", "Customer Sale", "Stock Audit", "Damaged / Expired", "Returned")

    val currentTotal = item.quantity * item.unitPrice
    val newTotal = targetQuantity * item.unitPrice
    val delta = targetQuantity - item.quantity
    val financialImpact = abs(delta) * item.unitPrice

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(
                    text = "Adjust Stock",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = item.name,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Interactive Stepper Row (-5, -1, +1, +5)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilledTonalButton(
                        onClick = {
                            targetQuantity = (targetQuantity - 5.0).coerceAtLeast(0.0)
                            quantityInputText = CurrencyFormatter.formatQuantity(targetQuantity)
                        },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("-5")
                    }

                    FilledTonalIconButton(
                        onClick = {
                            targetQuantity = (targetQuantity - 1.0).coerceAtLeast(0.0)
                            quantityInputText = CurrencyFormatter.formatQuantity(targetQuantity)
                        },
                        shape = CircleShape
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "Minus 1")
                    }

                    // Direct Numeric Input
                    OutlinedTextField(
                        value = quantityInputText,
                        onValueChange = { input ->
                            quantityInputText = input
                            input.toDoubleOrNull()?.let {
                                if (it >= 0.0) targetQuantity = it
                            }
                        },
                        label = { Text("Quantity") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier
                            .width(100.dp)
                            .testTag("adjust_stock_input"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    FilledTonalIconButton(
                        onClick = {
                            targetQuantity += 1.0
                            quantityInputText = CurrencyFormatter.formatQuantity(targetQuantity)
                        },
                        shape = CircleShape
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Plus 1")
                    }

                    FilledTonalButton(
                        onClick = {
                            targetQuantity += 5.0
                            quantityInputText = CurrencyFormatter.formatQuantity(targetQuantity)
                        },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("+5")
                    }
                }

                // Financial Impact Card
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = if (delta >= 0) StockGainGreen.copy(alpha = 0.12f) else StockLossRed.copy(alpha = 0.12f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (delta >= 0) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                                    contentDescription = null,
                                    tint = if (delta >= 0) StockGainGreen else StockLossRed,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (delta >= 0) "FINANCIAL INFLOW (ADDED)" else "FINANCIAL OUTFLOW (DEDUCTED)",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = if (delta >= 0) StockGainGreen else StockLossRed
                                )
                            }
                            Text(
                                text = "${if (delta >= 0) "+" else "-"}${CurrencyFormatter.formatInr(financialImpact)}",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (delta >= 0) StockGainGreen else StockLossRed
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Current: ${CurrencyFormatter.formatQuantity(item.quantity)} ${item.unit} (${CurrencyFormatter.formatInr(currentTotal)})",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "New: ${CurrencyFormatter.formatQuantity(targetQuantity)} ${item.unit} (${CurrencyFormatter.formatInr(newTotal)})",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                // Reason Selection Chips
                Text(
                    text = "Reason / Notes",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    presetReasons.take(3).forEach { reason ->
                        val isSelected = selectedReason == reason
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.weight(1f)
                        ) {
                            TextButton(
                                onClick = { selectedReason = reason },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = reason,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = customReason,
                    onValueChange = { customReason = it },
                    label = { Text("Custom Note (Optional)") },
                    placeholder = { Text("e.g. Invoice #204 / Customer sale") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("adjust_reason_input"),
                    shape = RoundedCornerShape(12.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val finalReason = if (customReason.isNotBlank()) customReason else selectedReason
                    onConfirmAdjustment(targetQuantity, delta, finalReason)
                },
                modifier = Modifier.testTag("confirm_adjust_btn"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (delta >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                )
            ) {
                Text("Confirm Update")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        },
        shape = RoundedCornerShape(24.dp)
    )
}
