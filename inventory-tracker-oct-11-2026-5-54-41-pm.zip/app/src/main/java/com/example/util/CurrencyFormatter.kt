package com.example.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object CurrencyFormatter {

    /**
     * Formats an amount into Indian Rupee (INR - ₹) format with standard Indian grouping (Lakhs & Crores).
     * e.g., 1250.0 -> "₹1,250.00", 125000.0 -> "₹1,25,000.00"
     */
    fun formatInr(amount: Double, showDecimals: Boolean = true): String {
        val isNegative = amount < 0
        val absAmount = Math.abs(amount)
        val integerPart = absAmount.toLong()
        val decimalPart = if (showDecimals) {
            val fraction = Math.round((absAmount - integerPart) * 100)
            String.format(Locale.US, ".%02d", fraction)
        } else ""

        val str = integerPart.toString()
        val formattedInt = if (str.length <= 3) {
            str
        } else {
            val lastThree = str.substring(str.length - 3)
            val rest = str.substring(0, str.length - 3)
            val parts = mutableListOf<String>()
            var i = rest.length
            while (i > 0) {
                val start = Math.max(0, i - 2)
                parts.add(0, rest.substring(start, i))
                i -= 2
            }
            parts.joinToString(",") + "," + lastThree
        }

        val formatted = "₹$formattedInt$decimalPart"
        return if (isNegative) "-$formatted" else formatted
    }

    /**
     * Formats quantity cleanly: "12" instead of "12.0", but "12.5" if fractional.
     */
    fun formatQuantity(qty: Double): String {
        return if (qty % 1.0 == 0.0) {
            qty.toLong().toString()
        } else {
            String.format(Locale.US, "%.2f", qty)
        }
    }

    /**
     * Formats timestamp into readable date time: "11 Oct 2026, 04:30 PM"
     */
    fun formatDateTime(timestamp: Long): String {
        val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }

    /**
     * Formats timestamp into date only: "11 Oct"
     */
    fun formatDate(timestamp: Long): String {
        val sdf = SimpleDateFormat("dd MMM", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }

    /**
     * Formats timestamp into short day of week: "Mon", "Tue"
     */
    fun formatDayOfWeek(timestamp: Long): String {
        val sdf = SimpleDateFormat("EEE", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }
}
