package com.example.util

import com.example.data.local.InventoryItem
import com.example.data.local.TransactionLog

object CsvHelper {

    fun itemsToCsv(items: List<InventoryItem>): String {
        val sb = StringBuilder()
        // Header
        sb.append("id,name,category,unit,quantity,unitPrice,lowStockThreshold,sku,lastUpdated\n")
        for (item in items) {
            sb.append(escape(item.id.toString())).append(",")
            sb.append(escape(item.name)).append(",")
            sb.append(escape(item.category)).append(",")
            sb.append(escape(item.unit)).append(",")
            sb.append(item.quantity).append(",")
            sb.append(item.unitPrice).append(",")
            sb.append(item.lowStockThreshold).append(",")
            sb.append(escape(item.sku)).append(",")
            sb.append(item.lastUpdated).append("\n")
        }
        return sb.toString()
    }

    fun logsToCsv(logs: List<TransactionLog>): String {
        val sb = StringBuilder()
        // Header
        sb.append("id,itemId,itemName,actionType,quantityChange,unitPrice,totalAmount,notes,timestamp\n")
        for (log in logs) {
            sb.append(escape(log.id.toString())).append(",")
            sb.append(escape(log.itemId.toString())).append(",")
            sb.append(escape(log.itemName)).append(",")
            sb.append(escape(log.actionType)).append(",")
            sb.append(log.quantityChange).append(",")
            sb.append(log.unitPrice).append(",")
            sb.append(log.totalAmount).append(",")
            sb.append(escape(log.notes)).append(",")
            sb.append(log.timestamp).append("\n")
        }
        return sb.toString()
    }

    fun parseItemsFromCsv(csvContent: String): List<InventoryItem> {
        val lines = csvContent.lines().filter { it.isNotBlank() }
        if (lines.size <= 1) return emptyList()

        val items = mutableListOf<InventoryItem>()
        // Skip header
        for (i in 1 until lines.size) {
            val tokens = parseCsvLine(lines[i])
            if (tokens.size >= 6) {
                try {
                    val name = tokens.getOrNull(1)?.trim() ?: continue
                    val category = tokens.getOrNull(2)?.trim() ?: "General"
                    val unit = tokens.getOrNull(3)?.trim() ?: "pcs"
                    val quantity = tokens.getOrNull(4)?.trim()?.toDoubleOrNull() ?: 0.0
                    val unitPrice = tokens.getOrNull(5)?.trim()?.toDoubleOrNull() ?: 0.0
                    val lowStock = tokens.getOrNull(6)?.trim()?.toDoubleOrNull() ?: 5.0
                    val sku = tokens.getOrNull(7)?.trim() ?: ""
                    val lastUpdated = tokens.getOrNull(8)?.trim()?.toLongOrNull() ?: System.currentTimeMillis()

                    items.add(
                        InventoryItem(
                            id = 0, // Generate new ID on restore/import to avoid collision
                            name = name,
                            category = category,
                            unit = unit,
                            quantity = quantity,
                            unitPrice = unitPrice,
                            lowStockThreshold = lowStock,
                            sku = sku,
                            lastUpdated = lastUpdated
                        )
                    )
                } catch (_: Exception) {
                    // Skip malformed row
                }
            }
        }
        return items
    }

    private fun escape(data: String): String {
        var escaped = data.replace("\"", "\"\"")
        if (escaped.contains(",") || escaped.contains("\n") || escaped.contains("\"")) {
            escaped = "\"$escaped\""
        }
        return escaped
    }

    private fun parseCsvLine(line: String): List<String> {
        val result = mutableListOf<String>()
        val curVal = StringBuilder()
        var inQuotes = false

        var i = 0
        while (i < line.length) {
            val ch = line[i]
            if (inQuotes) {
                if (ch == '\"') {
                    if (i + 1 < line.length && line[i + 1] == '\"') {
                        curVal.append('\"')
                        i++
                    } else {
                        inQuotes = false
                    }
                } else {
                    curVal.append(ch)
                }
            } else {
                if (ch == '\"') {
                    inQuotes = true
                } else if (ch == ',') {
                    result.add(curVal.toString())
                    curVal.setLength(0)
                } else {
                    curVal.append(ch)
                }
            }
            i++
        }
        result.add(curVal.toString())
        return result
    }
}
