package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Entity representing an inventory transaction / audit log.
 */
@Entity(tableName = "transaction_logs")
data class TransactionLog(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val itemId: Long,
    val itemName: String,
    val actionType: String, // "ADDED", "DEDUCTED", "CREATED", "UPDATED", "DELETED"
    val quantityChange: Double,
    val unitPrice: Double, // Unit price in INR at transaction time
    val totalAmount: Double, // abs(quantityChange) * unitPrice
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
