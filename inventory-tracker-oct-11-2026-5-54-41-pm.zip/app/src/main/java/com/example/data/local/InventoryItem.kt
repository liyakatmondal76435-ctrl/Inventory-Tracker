package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Entity representing an inventory item.
 */
@Entity(tableName = "inventory_items")
data class InventoryItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val category: String,
    val unit: String = "pcs",
    val quantity: Double,
    val unitPrice: Double, // Price per unit in INR (₹)
    val lowStockThreshold: Double = 5.0,
    val sku: String = "",
    val lastUpdated: Long = System.currentTimeMillis()
) {
    val totalValue: Double
        get() = quantity * unitPrice

    val isLowStock: Boolean
        get() = quantity <= lowStockThreshold
}
