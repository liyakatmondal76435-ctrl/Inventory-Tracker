package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TransactionLogDao {
    @Query("SELECT * FROM transaction_logs ORDER BY timestamp DESC")
    fun getAllLogs(): Flow<List<TransactionLog>>

    @Query("SELECT * FROM transaction_logs WHERE itemId = :itemId ORDER BY timestamp DESC")
    fun getLogsForItem(itemId: Long): Flow<List<TransactionLog>>

    @Query("SELECT * FROM transaction_logs WHERE actionType = :actionType ORDER BY timestamp DESC")
    fun getLogsByAction(actionType: String): Flow<List<TransactionLog>>

    @Query("SELECT * FROM transaction_logs WHERE timestamp >= :fromTimestamp AND timestamp <= :toTimestamp ORDER BY timestamp ASC")
    fun getLogsForPeriod(fromTimestamp: Long, toTimestamp: Long): Flow<List<TransactionLog>>

    @Query("SELECT * FROM transaction_logs WHERE timestamp >= :fromTimestamp AND timestamp <= :toTimestamp ORDER BY timestamp ASC")
    suspend fun getLogsSnapshotForPeriod(fromTimestamp: Long, toTimestamp: Long): List<TransactionLog>

    @Query("SELECT * FROM transaction_logs ORDER BY timestamp DESC")
    suspend fun getAllLogsSnapshot(): List<TransactionLog>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: TransactionLog): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLogs(logs: List<TransactionLog>): List<Long>

    @Query("DELETE FROM transaction_logs")
    suspend fun clearAllLogs()

    @Query("DELETE FROM transaction_logs WHERE id = :id")
    suspend fun deleteLogById(id: Long)
}
