package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [InventoryItem::class, TransactionLog::class],
    version = 1,
    exportSchema = false
)
abstract class InventoryDatabase : RoomDatabase() {

    abstract fun inventoryDao(): InventoryDao
    abstract fun transactionLogDao(): TransactionLogDao

    companion object {
        @Volatile
        private var INSTANCE: InventoryDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): InventoryDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    InventoryDatabase::class.java,
                    "inventory_tracker_database"
                )
                    .addCallback(InventoryDatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class InventoryDatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database.inventoryDao(), database.transactionLogDao())
                    }
                }
            }

            private suspend fun populateInitialData(
                itemDao: InventoryDao,
                logDao: TransactionLogDao
            ) {
                val now = System.currentTimeMillis()
                val oneDay = 24 * 60 * 60 * 1000L

                val initialItems = listOf(
                    InventoryItem(
                        id = 1,
                        name = "Colgate MaxFresh Gel",
                        category = "Personal Care",
                        unit = "pcs",
                        quantity = 18.0,
                        unitPrice = 95.0,
                        lowStockThreshold = 5.0,
                        sku = "PC-COLG-01",
                        lastUpdated = now - (oneDay * 2)
                    ),
                    InventoryItem(
                        id = 2,
                        name = "Dove Nourishing Shampoo",
                        category = "Personal Care",
                        unit = "bottles",
                        quantity = 3.0, // Low stock warning!
                        unitPrice = 240.0,
                        lowStockThreshold = 5.0,
                        sku = "PC-DOVE-02",
                        lastUpdated = now - (oneDay * 1)
                    ),
                    InventoryItem(
                        id = 3,
                        name = "Basmati Premium Rice",
                        category = "Groceries",
                        unit = "kg",
                        quantity = 35.0,
                        unitPrice = 145.0,
                        lowStockThreshold = 10.0,
                        sku = "GROC-RICE-03",
                        lastUpdated = now - (oneDay * 3)
                    ),
                    InventoryItem(
                        id = 4,
                        name = "Tata Tea Gold",
                        category = "Groceries",
                        unit = "packs",
                        quantity = 12.0,
                        unitPrice = 190.0,
                        lowStockThreshold = 4.0,
                        sku = "GROC-TEA-04",
                        lastUpdated = now - (oneDay * 4)
                    ),
                    InventoryItem(
                        id = 5,
                        name = "Dettol Antiseptic Liquid",
                        category = "Health & Hygiene",
                        unit = "bottles",
                        quantity = 2.0, // Low stock warning!
                        unitPrice = 160.0,
                        lowStockThreshold = 5.0,
                        sku = "HLTH-DETT-05",
                        lastUpdated = now - (oneDay * 1)
                    ),
                    InventoryItem(
                        id = 6,
                        name = "Fast Charging USB-C Cable",
                        category = "Electronics",
                        unit = "pcs",
                        quantity = 24.0,
                        unitPrice = 299.0,
                        lowStockThreshold = 6.0,
                        sku = "ELEC-USBC-06",
                        lastUpdated = now - (oneDay * 5)
                    ),
                    InventoryItem(
                        id = 7,
                        name = "A4 Premium Copier Paper",
                        category = "Stationery",
                        unit = "reams",
                        quantity = 15.0,
                        unitPrice = 330.0,
                        lowStockThreshold = 5.0,
                        sku = "STAT-A4-07",
                        lastUpdated = now - (oneDay * 6)
                    ),
                    InventoryItem(
                        id = 8,
                        name = "Fortune Mustard Oil",
                        category = "Groceries",
                        unit = "liters",
                        quantity = 20.0,
                        unitPrice = 175.0,
                        lowStockThreshold = 5.0,
                        sku = "GROC-OIL-08",
                        lastUpdated = now
                    )
                )

                itemDao.insertItems(initialItems)

                // Populate history for the past 7 days to give vibrant graphs immediately
                val sampleLogs = listOf(
                    TransactionLog(
                        id = 1,
                        itemId = 7,
                        itemName = "A4 Premium Copier Paper",
                        actionType = "ADDED",
                        quantityChange = 15.0,
                        unitPrice = 330.0,
                        totalAmount = 4950.0,
                        notes = "Initial stock purchase",
                        timestamp = now - (oneDay * 6)
                    ),
                    TransactionLog(
                        id = 2,
                        itemId = 6,
                        itemName = "Fast Charging USB-C Cable",
                        actionType = "ADDED",
                        quantityChange = 30.0,
                        unitPrice = 299.0,
                        totalAmount = 8970.0,
                        notes = "Bulk vendor shipment",
                        timestamp = now - (oneDay * 5)
                    ),
                    TransactionLog(
                        id = 3,
                        itemId = 6,
                        itemName = "Fast Charging USB-C Cable",
                        actionType = "DEDUCTED",
                        quantityChange = -6.0,
                        unitPrice = 299.0,
                        totalAmount = 1794.0,
                        notes = "Customer sales order #104",
                        timestamp = now - (oneDay * 4)
                    ),
                    TransactionLog(
                        id = 4,
                        itemId = 4,
                        itemName = "Tata Tea Gold",
                        actionType = "ADDED",
                        quantityChange = 15.0,
                        unitPrice = 190.0,
                        totalAmount = 2850.0,
                        notes = "Weekly replenishment",
                        timestamp = now - (oneDay * 4)
                    ),
                    TransactionLog(
                        id = 5,
                        itemId = 3,
                        itemName = "Basmati Premium Rice",
                        actionType = "ADDED",
                        quantityChange = 40.0,
                        unitPrice = 145.0,
                        totalAmount = 5800.0,
                        notes = "Wholesale crate received",
                        timestamp = now - (oneDay * 3)
                    ),
                    TransactionLog(
                        id = 6,
                        itemId = 3,
                        itemName = "Basmati Premium Rice",
                        actionType = "DEDUCTED",
                        quantityChange = -5.0,
                        unitPrice = 145.0,
                        totalAmount = 725.0,
                        notes = "Retail sale dispatch",
                        timestamp = now - (oneDay * 2)
                    ),
                    TransactionLog(
                        id = 7,
                        itemId = 1,
                        itemName = "Colgate MaxFresh Gel",
                        actionType = "ADDED",
                        quantityChange = 20.0,
                        unitPrice = 95.0,
                        totalAmount = 1900.0,
                        notes = "New carton arrival",
                        timestamp = now - (oneDay * 2)
                    ),
                    TransactionLog(
                        id = 8,
                        itemId = 2,
                        itemName = "Dove Nourishing Shampoo",
                        actionType = "DEDUCTED",
                        quantityChange = -4.0,
                        unitPrice = 240.0,
                        totalAmount = 960.0,
                        notes = "Counter sale",
                        timestamp = now - (oneDay * 1)
                    ),
                    TransactionLog(
                        id = 9,
                        itemId = 5,
                        itemName = "Dettol Antiseptic Liquid",
                        actionType = "DEDUCTED",
                        quantityChange = -3.0,
                        unitPrice = 160.0,
                        totalAmount = 480.0,
                        notes = "Walk-in purchase",
                        timestamp = now - (oneDay * 1)
                    ),
                    TransactionLog(
                        id = 10,
                        itemId = 8,
                        itemName = "Fortune Mustard Oil",
                        actionType = "ADDED",
                        quantityChange = 20.0,
                        unitPrice = 175.0,
                        totalAmount = 3500.0,
                        notes = "Morning delivery crate",
                        timestamp = now
                    )
                )

                logDao.insertLogs(sampleLogs)
            }
        }
    }
}
