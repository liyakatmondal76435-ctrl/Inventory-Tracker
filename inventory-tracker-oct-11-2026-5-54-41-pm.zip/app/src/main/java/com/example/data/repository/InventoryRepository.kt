package com.example.data.repository

import com.example.data.local.InventoryDao
import com.example.data.local.InventoryItem
import com.example.data.local.TransactionLog
import com.example.data.local.TransactionLogDao
import com.example.util.CsvHelper
import kotlinx.coroutines.flow.Flow
import kotlin.math.abs

class InventoryRepository(
    private val inventoryDao: InventoryDao,
    private val transactionLogDao: TransactionLogDao
) {

    val allItems: Flow<List<InventoryItem>> = inventoryDao.getAllItems()
    val allLogs: Flow<List<TransactionLog>> = transactionLogDao.getAllLogs()

    fun searchItems(query: String): Flow<List<InventoryItem>> =
        inventoryDao.searchItems(query)

    fun getLowStockItems(): Flow<List<InventoryItem>> =
        inventoryDao.getLowStockItems()

    fun getLogsForPeriod(fromTimestamp: Long, toTimestamp: Long): Flow<List<TransactionLog>> =
        transactionLogDao.getLogsForPeriod(fromTimestamp, toTimestamp)

    suspend fun getLogsSnapshotForPeriod(fromTimestamp: Long, toTimestamp: Long): List<TransactionLog> =
        transactionLogDao.getLogsSnapshotForPeriod(fromTimestamp, toTimestamp)

    suspend fun addItem(item: InventoryItem, note: String = "Initial stock entry"): Long {
        val insertedId = inventoryDao.insertItem(item)
        if (item.quantity > 0) {
            val log = TransactionLog(
                itemId = insertedId,
                itemName = item.name,
                actionType = "ADDED",
                quantityChange = item.quantity,
                unitPrice = item.unitPrice,
                totalAmount = item.quantity * item.unitPrice,
                notes = note,
                timestamp = System.currentTimeMillis()
            )
            transactionLogDao.insertLog(log)
        }
        return insertedId
    }

    suspend fun updateItemDetails(updatedItem: InventoryItem) {
        inventoryDao.updateItem(updatedItem)
    }

    suspend fun adjustStock(
        item: InventoryItem,
        delta: Double,
        actionReason: String,
        actionType: String = if (delta >= 0) "ADDED" else "DEDUCTED"
    ) {
        val newQuantity = (item.quantity + delta).coerceAtLeast(0.0)
        val actualDelta = newQuantity - item.quantity
        if (actualDelta == 0.0) return

        val updatedItem = item.copy(
            quantity = newQuantity,
            lastUpdated = System.currentTimeMillis()
        )
        inventoryDao.updateItem(updatedItem)

        val log = TransactionLog(
            itemId = item.id,
            itemName = item.name,
            actionType = actionType,
            quantityChange = actualDelta,
            unitPrice = item.unitPrice,
            totalAmount = abs(actualDelta) * item.unitPrice,
            notes = actionReason,
            timestamp = System.currentTimeMillis()
        )
        transactionLogDao.insertLog(log)
    }

    suspend fun setStockDirect(
        item: InventoryItem,
        newQuantity: Double,
        reason: String
    ) {
        val delta = newQuantity - item.quantity
        val actionType = if (delta >= 0) "ADDED" else "DEDUCTED"
        adjustStock(item, delta, reason, actionType)
    }

    suspend fun deleteItem(item: InventoryItem) {
        inventoryDao.deleteItem(item)
        val log = TransactionLog(
            itemId = item.id,
            itemName = item.name,
            actionType = "DELETED",
            quantityChange = -item.quantity,
            unitPrice = item.unitPrice,
            totalAmount = item.quantity * item.unitPrice,
            notes = "Item removed from inventory",
            timestamp = System.currentTimeMillis()
        )
        transactionLogDao.insertLog(log)
    }

    suspend fun exportItemsCsv(): String {
        val items = inventoryDao.getItemsSnapshot()
        return CsvHelper.itemsToCsv(items)
    }

    suspend fun exportLogsCsv(): String {
        val logs = transactionLogDao.getAllLogsSnapshot()
        return CsvHelper.logsToCsv(logs)
    }

    suspend fun importItemsCsv(csvContent: String): Int {
        val parsed = CsvHelper.parseItemsFromCsv(csvContent)
        if (parsed.isNotEmpty()) {
            inventoryDao.insertItems(parsed)
        }
        return parsed.size
    }

    suspend fun clearHistory() {
        transactionLogDao.clearAllLogs()
    }
}
